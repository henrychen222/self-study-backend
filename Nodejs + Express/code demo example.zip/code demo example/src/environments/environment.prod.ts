export const environment = {
  production: true,
  apiUrl: "http://nodeofangular-env.ar7pws7i8j.us-east-2.elasticbeanstalk.com/api"
};
